<?php

namespace TiendaEnLinea\Events;

abstract class Event
{
    //
}
