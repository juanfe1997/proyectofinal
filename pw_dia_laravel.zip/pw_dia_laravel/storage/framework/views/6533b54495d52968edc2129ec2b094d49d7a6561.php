<?php $__env->startSection('titulo', 'Index Usuarios'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1 class="text-center">Listado de Usuarios</h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
        <li><a href="<?php echo e(route('usuarios.index')); ?>">Usuarios</a></li>
        <li class="active">Index</li>
    </ol>
    <?php if(Session::has('alert')): ?>
        <div class="alert alert-success"><?php echo Session::get('alert'); ?></div>
    <?php endif; ?>
    <div class="col-md-10 col-md-offset-1">
        <a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-success"><i class="fa fa-user" aria-hidden="true"></i> Crear Usuario</a>
    </div>
    <div class="col-md-10 col-md-offset-1">
        <!-- Datatables -->
        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Email</th>
                <th>Opciones</th>
            </tr>
            </thead>
            <tfoot>
            <tr>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Email</th>
                <th>Opciones</th>
            </tr>
            </tfoot>
            <tbody>
            <?php foreach($usuarios as $usuario): ?>
                <tr>
                    <td><?php echo e($usuario->nombre); ?></td>
                    <td><?php echo e($usuario->apellido); ?></td>
                    <td><?php echo e($usuario->email); ?></td>
                    <td>
                        <a href="<?php echo e(route('usuarios.show', $usuario->id)); ?>" class="btn btn-primary" data-toggle="tooltip" data-placement="left" title="Ver"><i class="fa fa-search-plus" aria-hidden="true"></i></a>
                        <a href="<?php echo e(route('usuarios.edit', $usuario->id)); ?>" class="btn btn-warning" data-toggle="tooltip" data-placement="top" title="Editar"><i class="fa fa-edit" aria-hidden="true"></i></a>
                        <a href="<?php echo e(url('usuarios/eliminar', $usuario->id)); ?>" class="btn btn-danger" data-toggle="tooltip" data-placement="right" title="Eliminar" onclick="return confirm('Estas seguro de eliminar el usuario')"><i class="fa fa-trash" aria-hidden="true"></i></a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <!-- fin Datatables -->
    </div>
    <?php $__env->startSection('scripts'); ?>
        <?php echo $__env->make('scripts.datatable_tooltip', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>